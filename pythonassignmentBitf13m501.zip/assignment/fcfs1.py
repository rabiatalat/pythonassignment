array = []

wTime = 0.0

n = int(rInput('Enter the No. of Process : '))

for i in xrange(n):
	array.append([])
	print ' '
	array[i].append(rInput('Enter Process Name : ' ))
	array[i].append(int(rInput('Enter arrayival Time ')))
	array[i].append(int(rInput('Enter Burst Time :')))
	print ' '


array.sort(key = lambda array:array[1])

wait = []

j = 1

service = []

service.append(array[0][1])

wait.append(service[0] - array[0][1])

while (j<n):
	service.append(service[j-1] + array[j-1][2])
	wait.append(service[j] - array[j][1])
	wTime += wait[j]
	j += 1

print 'Process Name \tarrayival Time \t Burst Time \t Service Time \t Waiting Time'

for i in xrange(n):
	print array[i][0] ,'\t\t' ,array[i][1] ,'\t\t', array[i][2], '\t\t',service[i],'\t\t',wait[i]


print 'Total Waiting Time : ',wTime

print 'Average Waiting Time : ',(wTime/(n*1.0))
