array = []

wTime = 0

n = int(rInput('Enter the No. of Process : '))


for i in xrange(n):
	array.append([])
	print ' '
	array[i].append(rInput('Enter Process Name : ' ))
	array[i].append(int(rInput('Enter arrayival Time :')))
	array[i].append(int(rInput('Enter Burst Time :')))
	array[i].append(int(rInput('Enter Priority :')))
	print ' '

	
time_slice = int(rInput('Enter the time slice for Process : '))

array.sort(key = lambda array:(array[1],array[3]))

total = 0

wait = []

finish = []

dup = []

for i in xrange(n):
	finish.append(0)
	total += array[i][2]
	dup.append(array[i][2])
	wait.append(0)


j = 0
l = 0

while (l<total):
	j = j % n
	for k in xrange(time_slice):
		if(dup[j] != 0):
			dup[j] -= 1
			l += 1
			if (dup[j] == 0):
				finish[j] = l + array[j][1]
				break
	j += 1

	
for i in xrange(n):
	wait[i]  = finish[i] - array[i][1] - array[i][2]

	
print 'Process Name \tarrayival Time \t Burst Time \t  Waiting Time'

for i in xrange(n):
	print array[i][0] ,'\t\t' ,array[i][1] ,'\t\t', array[i][2], '\t\t',wait[i]
	wTime += wait[i]

	
print 'Total Waiting Time : ',wTime

print 'Average Waiting Time : ',(wTime/n)
